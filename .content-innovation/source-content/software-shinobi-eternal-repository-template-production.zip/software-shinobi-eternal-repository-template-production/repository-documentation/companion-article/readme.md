# software-shinobi-eternal-repository-template companion article

## Namaste
