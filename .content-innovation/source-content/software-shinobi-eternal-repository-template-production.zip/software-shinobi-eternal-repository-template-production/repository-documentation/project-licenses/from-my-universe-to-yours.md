# From My Universe To Yours, With Lots Of Love.

In order to receive we must share.

Or something like that.

In this repository and others like it, I have shared many things.

The contents of this repository have been created to fulfill a singular Intention.

## The Singular Intention

It is my Intention that the fruits of my software development labor will be shared with and consumed by the Universe forever and forever.

## Namaste.

--

With Lots Of Love,

Software Shinobi
