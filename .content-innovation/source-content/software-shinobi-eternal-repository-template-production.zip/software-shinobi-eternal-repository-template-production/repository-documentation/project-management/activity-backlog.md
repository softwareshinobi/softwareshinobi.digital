
:: sigh ::

## Build Automation

I want the jenkins file in this folder

i want the docker-compose file in this folder

i want the configuration file renamed to say what it is

i want the dockerfile in this folder

## Uncategorized

the Dockerfile should do nothing.

the project itself needs to build as a container that does nothing

this project itself needs to be exported to dockerhub

the pictures are wrong

i want to make the readme contain the intention bits

there isn't documentation what the folders are.

there isn't documentation about how to do a local quick start

there isn't documentation about how to do a dockerized quick start

use the proper markdown templates for a todo list

the docker file needs to use variables instead of copy-paste strings

docker-compose should match the dockerfile that you fix

i'd love a cascading configuration script, but that would be dangerous if others don't know how it works in the future.

project documentation should be an mkdocs folder with my ideal template situation

ithi