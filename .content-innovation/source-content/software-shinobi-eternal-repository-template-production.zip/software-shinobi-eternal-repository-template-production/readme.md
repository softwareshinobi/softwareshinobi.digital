# I Desire To Receive Software Developer Immortality.

In this repository will find a generic source code repository with baked-in capability for Jenkins pipelines, automated docker image builds, automated DockerHub deploys, and self-contained documentation.

![Software Shinobi External Repository Template](repository-documentation/images-pictures/cover-image.png)

## Prologue

I did this for Her.

I did this for the Universe.

## In The Beginning

In the beginning, there was a GitHub repository that would supersede them all.

This is that GitHub repository, and there are others.

In this repository will find a generic source code repository with baked-in capability for Jenkins pipelines, automated docker image builds, automated DockerHub deploys, and self-contained documentation.

This repository was created to be used/cloned/forked/extended/exploited by me, you, and especially the Universe to support our mission goals and intentions. Today and forever.

## A Repository Created With Love

In order to receive we must share. Or something like that.

It is my duty to share my gifts, as the gifts of others were shared with me.

In this repository and the repositories that extend this repository, I am sharing my software development fruit.

In addition to my duty to share, this repository and it's fruit was created to fulfill a selfish intention.

## The Selfish Intention

It is my Intention that the fruits of this repository and my software development fruit will be shared with and consumed by the Universe, today and forever and ever.

I desire that my fruit become eternal.

I desire to achieve software developer immortality.

I share this repository today to receive software developer immortality.

## Read The Repository Documentation

I put together a collection of content that goes into more detail about this repository.

So go read that repository documentation. Or don't, that's ok too.

Somewhere in there is RTFM humor.

[Read The Repository Documentation](repository-documentation/readme.md)

## Ciao

From My Universe To Yours With Lots Of Love,

Software Shinobi

## Namaste.