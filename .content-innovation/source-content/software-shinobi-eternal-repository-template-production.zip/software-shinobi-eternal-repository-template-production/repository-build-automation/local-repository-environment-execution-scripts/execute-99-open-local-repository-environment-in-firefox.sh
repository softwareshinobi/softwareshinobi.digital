#!/bin/bash

##

set -x

set -e

##

source ./local-repository-environment-scripts-common.sh

##

firefox localhost:8888 &
