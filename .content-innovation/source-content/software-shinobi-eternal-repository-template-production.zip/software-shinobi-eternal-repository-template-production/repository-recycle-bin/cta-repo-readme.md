## Quick Start: Software Shinobi External Repository Template

Want to clone and extend the software shinobi external repository template repository?
Great, i'm thrilled.

Clone this repo and run the following command:

```bash
sudo bash build-and-run-dockerized-project-locally.sh
```
