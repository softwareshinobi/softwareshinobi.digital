## Howdy! 👋👋

So umm... welcome to my GitHub page.

I'm Troy, a Software Developer & Technical Writer.

I design, code, test, document, and deploy software situations.

--

Should you be inclined, click the link below to see my stuff around the Internet.

You'll learn more about me, what I do and what I've created.

https://links.softwareshinobi.online

## How I Help As A Developer

As a developer, I do many things. Wear many hats.

It's a shared reality of existence as a software developer.

"Software Developer C'est La Vie", if you will.

If i tried to boil down what I do as a software developer into something short, I'd say something like the following:

- [ ] POC And MVP Development Support
- [ ] Rapid Software Prototyping
- [ ] Capability / Feasability / Research & Development
- [ ] Software Delivery and Operations Support

## About Me // Software Shinobi

In this section, I attempt to boil down over 15+ years of professional software development experience into like 100 words.

--

I've supported missions and initiatives in the private sector, the public sector, contracting, consulting, freelancing, and whatever is in between all that.

I can comfortably say that the fruits of my software development labor have been consumed by at least half a billion people around the Globe.

So like... that's cool. At least to me. At one point in my life.

And it's probably a billion people but i don't have the time to do the theoretical napkin math of source code impression proliferation.

Whatever any of that means.

```
Editor’s Note:

I totally love the idea of "Developer Of Fortune".

But like "Soldiers Of Fortune", but i’m like a contract killer but i'm not a killer.

I'm just a developer.

And I like… save the day with my keyboard and the linux terminal from 3rd world countries.

Like Jack Bauer in the south american jungle or something like that.

hmm... somebody get Steven Spielberg on the phone.
```

Anyways…

Here’s my LinkedIn.

Over on LinkedIn I go into more detail around my corporate experiences and stuff like that.

https://linkedin.com/in/software-shinobi

## My Tool Stack / The Tech I Use

The *very first lesson* in software developer school is blame the tools and the stack and the dev environment.

Blame everything on that. Everything. 

And when that doesn't work, blame the database. When that doesn't work, blame the network.

The *final lesson* of developer school is to not ever talk about developer school.

I think there were threats of public stoning or something like that. i don't remember.

--

So before I can blame everything on the tools and the stack and the dev environments...

I'll first need to share my own tools and stacks and dev environment stuff.

With this out of the way, i can start blaming other people's stacks.

| Capability |  |
|-------------------|--------|
|Languages   |  Java, SQL, JavaScript, HTML, JSP, React, React Native, Bash         
|Development Operations| Jenkins, Bamboo, Nexus, Git, Subversion, HP Fortify, Docker
|Virtualization| VMWare, Containers, VirtualBox, Xen
|Databases| MySQL, Oracle, Elasticsearch, DB2, Hadoop, SQL Server, MongoDB
|Application Servers| Wildfly, Tomcat, Glassfish, WebSphere
|Operating Systems| Microsoft Windows, Linux (RHEL, Ubuntu), Mac OS, Android, iOS, HP-UX
|Cloud Platforms and Services| Okta, Amazon AWS, ServiceNow, Digital Ocean, Form.io

## Check Out My Stuff

I once thumbed through a book that suggested in order to receive, we must share.

So let's do that.

When you've got a sec, browse through my AllMyLinks page at the link below.

On my AllMyLinks page I've shared things about me and I've shared what I've done and I've shared what I've created.

I like to think of it all as sharing my personal brand of magick with the Universe, with Intention. Whatever any of that means.

https://links.softwareshinobi.online

## How Can I Help Your Project As A Software Developer?

Shoot me an email.

Tell me about your software situation and how i can help!

troy@softwareshinobi.online

## Before You Go...

So thanks for stopping by.

I'd love to have you over again.

Until then, may the Universe give you all that you truly desire.

*The light in me acknowledges the light in you.*

umm...

K. Tks. Byeee.

--

From my Universe to yours with lots of love,

Troy "Software Shinobi" Burney

https://links.softwareshinobi.online
